from datetime import datetime, timedelta
from flask import Flask, jsonify, render_template, request, redirect, url_for, session, flash
from model import db, User, Zoom  # Import db and models from models.py

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Database configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///helpdesk.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize the database
db.init_app(app)

# Create the database tables
with app.app_context():
    db.create_all()
    # db.drop_all()



@app.before_request
def check_session_timeout():
    try:
        if 'session_timeout' in session:
            session_timeout = datetime.fromisoformat(session['session_timeout'])
            current_time = datetime.now()

            if current_time > session_timeout:
                # Session expired, log out the user
                user_name = session.get('name')
                if user_name:
                    user = User.query.filter_by(name=user_name).order_by(User.id.desc()).first()
                    if user:
                        user.status = "Logged Out (Session Expired)"
                        user.status_time = current_time
                        user.json_data.update({
                            "status": "Logged Out (Session Expired)",
                            "status_time": current_time.isoformat()
                        })
                        db.session.commit()
                session.clear()  # Clear the session
                return jsonify({"success": False, "message": "Session expired, please log in again"}), 401
            else:
                # Extend session timeout if still active
                session_timeout_minutes = 2  # Extend by 2 minutes (adjust as needed)
                session['session_timeout'] = (current_time + timedelta(minutes=session_timeout_minutes)).isoformat()
        # Allow the request to continue if no session is active
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500



@app.route('/api/heartbeat', methods=['POST'])
def heartbeat():
    try:
        if 'session_timeout' in session:
            session_timeout_minutes = 2  # Extend by 2 minutes (adjust as needed)
            session['session_timeout'] = (datetime.now() + timedelta(minutes=session_timeout_minutes)).isoformat()
            return jsonify({"success": True, "message": "Session timeout updated"}), 200
        else:
            return jsonify({"success": False, "message": "No active session"}), 401
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

    

@app.route('/api/login', methods=['POST'])
def api_login():
    try:
        json_data = request.get_json()
        current_time = datetime.now()  # Current timestamp
        session_timeout_minutes = 2  # Define session timeout duration in minutes
        session_timeout = current_time + timedelta(minutes=session_timeout_minutes)  

        user = User(
            name=json_data.get('name'),
            region=json_data.get('region'),
            raised_by=json_data.get('raised_by'),
            status="Logged in",
            status_time=current_time,  # Set the login time
            json_data={
                **json_data,
                "status":"logged in",
                "status_time": current_time.isoformat(),  # Include time in JSON
                
            }
        )
        db.session.add(user)
        db.session.commit()

        # Store the session for the logged-in user
        session['name'] = user.name
        session['region'] = user.region
        session['session_timeout'] = session_timeout.isoformat()  # Store session timeout in session
        return jsonify({"success": True, "session_timeout": session_timeout.isoformat()}), 200
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500



@app.route('/api/zoom', methods=['POST', 'PUT', 'GET', 'DELETE'])
def api_zoom():
    try:
        # Check if the user is logged in
        user_name = session.get('name')  # Logged-in user's name
        user_region = session.get('region')  # Logged-in user's region
        if not user_name or not user_region:
            return jsonify({"success": False, "message": "User not logged in"}), 403

        # Get the logged-in user's details from the User table
        user = User.query.filter_by(name=user_name).order_by(User.id.desc()).first()
        if not user:
            return jsonify({"success": False, "message": "User not found"}), 404

        json_data = request.get_json()

        # Handle Zoom creation (POST)
        if request.method == 'POST':
            zoom = Zoom(
                user_id=user.id,
                created_by=user.name,
                region=user.region,
                created_on=datetime.utcnow(),
                modified_by=None,
                modified_on=None,
                meeting_title=json_data.get('meeting_title'),
                description=json_data.get('description'),
                date=datetime.strptime(json_data.get('date'), '%Y-%m-%d').date(),
                time=datetime.strptime(json_data.get('time'), '%H:%M').time(),
                am_pm=json_data.get('am_pm'),
                time_hours=int(json_data.get('time_hours')),
                time_minutes=int(json_data.get('time_minutes')),
                remarks=json_data.get('remarks'),
                json_data={
                    **json_data,
                    "user_id": user.id,
                    "created_by": user.name,
                    "created_on": datetime.utcnow().isoformat(),
                    "modified_by": None,
                    "modified_on": None,
                    "region": user.region
                }
            )
            db.session.add(zoom)
            db.session.commit()
            return jsonify({"success": True, "message": "Zoom meeting created"}), 200

        # Handle Zoom updates (PUT)
        elif request.method == 'PUT':
            zoom_id = json_data.get('id')
            zoom = Zoom.query.filter_by(id=zoom_id).first()
            if not zoom:
                return jsonify({"success": False, "message": "Zoom meeting not found"}), 404

            zoom.meeting_title = json_data.get('meeting_title', zoom.meeting_title)
            zoom.description = json_data.get('description', zoom.description)
            zoom.date = datetime.strptime(json_data.get('date'), '%Y-%m-%d').date()
            zoom.time = datetime.strptime(json_data.get('time'), '%H:%M').time()
            zoom.am_pm = json_data.get('am_pm', zoom.am_pm)
            zoom.time_hours = int(json_data.get('time_hours', zoom.time_hours))
            zoom.time_minutes = int(json_data.get('time_minutes', zoom.time_minutes))
            zoom.remarks = json_data.get('remarks', zoom.remarks)

            zoom.modified_by = user.name
            zoom.modified_on = datetime.utcnow()

            zoom.json_data.update({
                **json_data,
                "modified_by": user.name,
                "modified_on": datetime.utcnow().isoformat()
            })

            db.session.commit()
            return jsonify({"success": True, "message": "Zoom meeting updated"}), 200

        # Handle Zoom retrieval (GET)
        elif request.method == 'GET':
            zoom_id = request.args.get('id')  # Retrieve a specific Zoom meeting by ID (optional)
            if zoom_id:
                zoom = Zoom.query.filter_by(id=zoom_id).first()
                if not zoom:
                    return jsonify({"success": False, "message": "Zoom meeting not found"}), 404
                return jsonify({"success": True, "data": zoom.json_data}), 200
            else:
                # Retrieve all Zoom meetings for the current user
                zooms = Zoom.query.filter_by(user_id=user.id).all()
                data = [zoom.json_data for zoom in zooms]
                return jsonify({"success": True, "data": data}), 200

        # Handle Zoom deletion (DELETE)
        elif request.method == 'DELETE':
            zoom_id = json_data.get('id')
            zoom = Zoom.query.filter_by(id=zoom_id).first()
            if not zoom:
                return jsonify({"success": False, "message": "Zoom meeting not found"}), 404

            db.session.delete(zoom)
            db.session.commit()
            return jsonify({"success": True, "message": "Zoom meeting deleted"}), 200

    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

@app.route('/')
def login():
    return render_template('login.html' , show_change_button=False)


@app.route('/logout', methods=['POST'])
def logout():
    try:
        print("Are you sure")
        # Get the logged-in user's name and check session timeout
        user_name = session.get('name')
        if user_name:
            # Fetch the most recent user entry for the logged-in user
            user = User.query.filter_by(name=user_name).order_by(User.id.desc()).first()
            # print("User in here", user)
            if user:
                current_time = datetime.utcnow()

                # Check if the session has expired
                session_timeout = session.get('session_timeout')
                if session_timeout and current_time > datetime.fromisoformat(session_timeout):
                    # Session has expired
                    status = "Logged Out (Session Expired)"
                else:
                    # Manual logout
                    status = "Logged Out"

                # Update user status and JSON
                user.status = status
                user.status_time = current_time

                if not user.json_data:
                    user.json_data = {}

                current_json = user.json_data
                updated_json = {}
                updated_json['name']= current_json.get("name", "")
                updated_json['region'] = current_json.get('region', '')
                updated_json['raised_by'] = current_json.get('raised_by','')
                updated_json['status'] =status
                updated_json['status_time'] = current_time.isoformat()

               
                user.json_data = updated_json
                

                db.session.commit()

        # Clear the session
        session.clear()
        return jsonify({"success": True}), 200
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

@app.route("/home/")
def home():
    
    name = session.get('name')
    region = session.get('region')
    raised_by = session.get('raised_by')
    
    
    return render_template("home.html", name=name, region=region,raised_by = raised_by,  show_change_button=True)


@app.route("/zoom/", methods=["GET", "POST"])  
def zoom():
    if request.method == "POST":
        try:
           
            meeting_title = request.form['meeting_title']
            description = request.form.get('description', '')  
            date = datetime.strptime(request.form['date'], '%Y-%m-%d').date()
            time = datetime.strptime(request.form['time'], '%H:%M').time()
            am_pm = request.form['am_pm']  
            time_hours = int(request.form['time_hours'])
            time_minutes = int(request.form['time_minutes'])
            remarks = request.form.get('remarks', '') 
   
            new_zoom = Zoom(
            meeting_title=meeting_title,
            description=description,
            date=date,
            time=time,
            am_pm=am_pm,
            time_hours=time_hours,
            time_minutes=time_minutes,
            remarks=remarks,
            json_data=request.form.to_dict()
        )  
            db.session.add(new_zoom)
            db.session.commit()

            flash("Zoom meeting saved successfully!", "success")
            return redirect(url_for('zoom'))  

        except Exception as e:
            db.session.rollback()
            return f"An error occurred: {e}"

    name = session.get('name')
    region = session.get('region')
    raised_by = session.get('raised_by')
    
    return render_template("zoom.html", name=name, region=region, raised_by=raised_by, show_change_button=True)




    # Entity Regristration route

@app.route("/registration/")
def registration():
    
    name = session.get('name')
    region = session.get('region')
    raised_by = session.get('raised_by')
    
    
    return render_template("registration.html", name=name, region=region,raised_by = raised_by,  show_change_button=True)


# route for Entity Reservation as BOOKME

@app.route("/bookme/")
def bookme():
    
    name = session.get('name')
    region = session.get('region')
    raised_by = session.get('raised_by')
    
    
    return render_template("bookme.html", name=name, region=region,raised_by = raised_by,  show_change_button=True)


if __name__ == '__main__':
    app.run(host='0.0.0.0' ,port=5000, debug=True) 