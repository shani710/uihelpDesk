from datetime import datetime
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    region = db.Column(db.String(100), nullable=False)
    raised_by = db.Column(db.String(100), nullable=False)
    status = db.Column(db.String(50), nullable=False, default="Logged Out")
    status_time = db.Column(db.DateTime, nullable=True)  # Timestamp of current status
    json_data = db.Column(db.JSON, nullable=True)
    def reindex_users():
        users = User.query.order_by(User.id).all()
        for index, user in enumerate(users, start=1):
            user.id = index
        db.session.commit()
    def user_info(self):
        return self.id, self.name, self.region, self.status, self.status, self.json_data

    def __repr__(self):
        return f'<User {self.name}>'
    

class Zoom(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, nullable=False)  # Foreign key to User table
    created_by = db.Column(db.String(100), nullable=False)
    region = db.Column(db.String(100), nullable=False)
    created_on = db.Column(db.DateTime, nullable=False, default=datetime.now)  # Set creation timestamp
    modified_by = db.Column(db.String(100), nullable=True)  # Last modified by user
    modified_on = db.Column(db.DateTime, nullable=True)  # Last modification timestamp
    meeting_title = db.Column(db.String(128), nullable=False)
    description = db.Column(db.String(256))
    date = db.Column(db.Date, nullable=False)
    time = db.Column(db.Time, nullable=False)
    am_pm = db.Column(db.String(2), nullable=False)
    time_hours = db.Column(db.Integer, nullable=False)
    time_minutes = db.Column(db.Integer, nullable=False)
    remarks = db.Column(db.String(256))
    json_data = db.Column(db.JSON, nullable=True)


    def __repr__(self):
        return f'<Zoom {self.meeting_title}>'