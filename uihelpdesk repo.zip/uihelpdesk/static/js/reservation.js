function generateTimeSlots() {
    const slotDuration = document.getElementById("slotDuration");
    let startTime = 6 * 60; // 6:00 AM in minutes
    let endTime = 18 * 60;  // 6:00 PM in minutes

    for (let time = startTime; time <= endTime; time += 30) {
      let hours = Math.floor(time / 60);
      let minutes = time % 60;
      let period = hours >= 12 ? "PM" : "AM";
      hours = hours % 12 || 12; // Convert to 12-hour format
      let timeString = `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")} ${period}`;
      let option = document.createElement("option");
      option.value = timeString;
      option.textContent = timeString;
      slotDuration.appendChild(option);
    }
  }

  // Call the function to generate time slots when the page loads
  generateTimeSlots();

  // Function to show the appropriate form based on the button clicked
  function showForm(formType) {
    if (formType === "registration") {
      document.getElementById("registrationForm").style.display = "block";
      document.getElementById("reservationForm").style.display = "none";
    } else if (formType === "reservation") {
      document.getElementById("reservationForm").style.display = "block";
      document.getElementById("registrationForm").style.display = "none";
    }
  }


  document.getElementById('entityType').addEventListener('change', function() {
    const type = this.value;
    // Hide all extra details containers by default
    document.getElementById('buildingDetails').style.display = 'none';
    document.getElementById('vehicleDetails').style.display = 'none';
    document.getElementById('staffDetails').style.display = 'none';
    
    // Display the extra details fieldset if a valid type is selected
    if (type === 'building' || type === 'vehicle' || type === 'staff') {
      document.getElementById('extraDetails').style.display = 'block';
    } else {
      document.getElementById('extraDetails').style.display = 'none';
    }
    
    // Show the appropriate extra details section based on selection
    if (type === 'building') {
      document.getElementById('buildingDetails').style.display = 'block';
    } else if (type === 'vehicle') {
      document.getElementById('vehicleDetails').style.display = 'block';
    } else if (type === 'staff') {
      document.getElementById('staffDetails').style.display = 'block';
    }
  });

  // // Optional function to toggle between registration and reservation forms
  // function showForm(formType) {
  //   if (formType === 'registration') {
  //     document.getElementById('registrationForm').style.display = 'block';
  //     document.getElementById('reservationForm').style.display = 'none';
  //   } else if (formType === 'reservation') {
  //     document.getElementById('registrationForm').style.display = 'none';
  //     document.getElementById('reservationForm').style.display = 'block';
  //   }
  // }

//   entity extra details toggle fieldset form 

function showForm(formType) {
    document.getElementById('registrationForm').style.display = formType === 'registration' ? 'block' : 'none';
    document.getElementById('reservationForm').style.display = formType === 'reservation' ? 'block' : 'none';
}

function showExtraDetails() {
    const entityType = document.getElementById('entityTypeReservation').value;
    const extraDetails = document.getElementById('extraDetailsReservation');
    const buildingDetails = document.getElementById('buildingDetailsReservation');
    const vehicleDetails = document.getElementById('vehicleDetailsReservation');
    const staffDetails = document.getElementById('staffDetailsReservation');

    extraDetails.style.display = 'block';
    buildingDetails.style.display = entityType === 'building' ? 'block' : 'none';
    vehicleDetails.style.display = entityType === 'vehicle' ? 'block' : 'none';
    staffDetails.style.display = entityType === 'staff' ? 'block' : 'none';
}