function updateDateTime() {
    const dateTimeElement = document.getElementById('currentDateTime');
    const now = new Date();
    const options = { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' };
    dateTimeElement.textContent = now.toLocaleDateString('en-US', options);
}

updateDateTime(); // Initial call to display the time immediately
setInterval(updateDateTime, 1000); // Update every second


const currentDate = new Date();
const yearFromNow = new Date();

// Calculate the date one year from now
yearFromNow.setFullYear(currentDate.getFullYear() + 1);

// Format the dates as YYYY-MM-DD
const formatDate = (date) => {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are 0-based
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

// Set the min and max attributes for the input field
const dateInput = document.getElementById('date');
dateInput.min = formatDate(currentDate);
dateInput.max = formatDate(yearFromNow);


