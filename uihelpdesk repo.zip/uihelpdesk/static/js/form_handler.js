// Collect form data and convert it to JSON
function collectFormData(formId) {
    const form = document.getElementById(formId);
    const formData = new FormData(form);
    const jsonData = {};

    for (let [key, value] of formData.entries()) {
        jsonData[key] = value;
    }

    return JSON.stringify(jsonData);
}

// Send JSON data to the server
function submitFormData(url, jsonData, successCallback, errorCallback) {
    fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: jsonData
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                if (successCallback) successCallback(data);
            } else {
                if (errorCallback) errorCallback(data.message);
            }
        })
        .catch(error => {
            if (errorCallback) errorCallback(error.message);
        });
}

// Update status (login/logout)
function updateStatus(url, successCallback, errorCallback) {
    fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                if (successCallback) successCallback(data);
            } else {
                if (errorCallback) errorCallback(data.message);
            }
        })
        .catch(error => {
            if (errorCallback) errorCallback(error.message);
        });
}

// Add event listeners to the forms
document.addEventListener("DOMContentLoaded", function () {
    // For login form
    const loginForm = document.getElementById("login-form");
    if (loginForm) {
        loginForm.addEventListener("submit", function (e) {
            e.preventDefault();
            const jsonData = collectFormData("login-form");
            submitFormData("/api/login", jsonData,
                () => {
                    alert("Login data saved successfully!");
                    window.location.href = "/home";
                },
                (error) => alert("Error: " + error)
            );
        });
    }

    // For Zoom form
    const zoomForm = document.getElementById("zoom-form");
    if (zoomForm) {
        zoomForm.addEventListener("submit", function (e) {
            e.preventDefault();
            const jsonData = collectFormData("zoom-form");
            submitFormData("/api/zoom", jsonData,
                () => {
                    alert("Zoom data saved successfully!");
                    window.location.href = "/zoom";
                },
                (error) => alert("Error: " + error)
            );
        });
    }

    // For logout button
    const logoutButton = document.getElementById("logout-button");
    if (logoutButton) {
        logoutButton.addEventListener("click", function (e) {
            e.preventDefault(); // Prevent default action
            fetch("/logout", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                }
            })
                .then(response => {
                    if (response.ok) {
                        alert("Are you Sure!");
                        window.location.href = "/"; // Redirect to login page
                    } else {
                        response.json().then(data => {
                            alert("Logout failed: " + (data.message || "Unknown error"));
                        });
                    }
                })
                .catch(error => alert("Error: " + error.message));
        });
    }
});


let heartbeatInterval = 60 * 1000; // Send heartbeat every 1 minute
let userActivityTimeout;

// Function to send heartbeat to the backend
const sendHeartbeat = () => {
    fetch('/api/heartbeat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
    })
    .then(response => response.json())
    .then(data => console.log('Heartbeat sent:', data))
    .catch(error => console.error('Error sending heartbeat:', error));
};

// Function to reset heartbeat timer on user activity
const resetHeartbeatTimer = () => {
    clearTimeout(userActivityTimeout);
    userActivityTimeout = setTimeout(sendHeartbeat, heartbeatInterval);
};

// Attach event listeners for user activity
window.addEventListener('mousemove', resetHeartbeatTimer);
window.addEventListener('keypress', resetHeartbeatTimer);
window.addEventListener('click', resetHeartbeatTimer);

// Start initial heartbeat timer
resetHeartbeatTimer();




function validateDatalistInput(inputElement, datalistId) {
    const datalist = document.getElementById(datalistId);
    const options = Array.from(datalist.options).map(option => option.value);
    const inputValue = inputElement.value;

    if (!options.includes(inputValue)) {
        inputElement.value = ""; // Clear input if it doesn't match
    }
}

// Attach event listeners to the fields
document.addEventListener("DOMContentLoaded", function () {
    const staffNameInput = document.getElementById("staffName");
    const raisedByInput = document.getElementById("raisedBy");

    staffNameInput.addEventListener("change", function () {
        validateDatalistInput(staffNameInput, "staffList");
    });

    raisedByInput.addEventListener("change", function () {
        validateDatalistInput(raisedByInput, "staffList");
    });
});