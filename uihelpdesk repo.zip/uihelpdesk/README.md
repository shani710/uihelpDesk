
# DEPLOYMENT STEPS FOR Local Machine:

### STEP:1 clone git on local machine:
```bash
# cd to your required folder in which you want to clone the git
$ mkdir live-repo
$ cd live-repo
$ git clone abbas@ngx.dev.iipak.local:~/ita-team/source-repo/ga-rnd-uihelpdesk.git uihelpdesk
# Enter the password
# A repo [ga-rnd-uihelpdesk.git] will be cloned to the [uihelpdesk] folder
$ git status
$ git pull
$ git log
# update this folder with your desired project files and structure.
```

### STEP:2 Create virtual environment in the project folder:
- local server
```bash
$ cd live-repo/uihelpdesk
$ python3 -m venv appvenv
$ source appvenv/bin/activate
$ pip install wheel # installing pip
$ pip freeze > reqirements.txt # run this command every time when use pip install
```


# DEPLOYMENT STEPS FOR IIPAK SERVER:
- Following are the steps followed for this deployment:


## STEP:1 Create a virtual environment in the project folder:
```bash
$ cd live-repo/uihelpdesk
$ python3 -m venv appvenv
$ source appvenv/bin/activate
$ pip install wheel
$ pip install -r requirements.txt
``` 


## STEP:2 Checking if the project main file is running:
```bash
$ sudo ufw allow 5000
$ python app.py
# hit CTRL-C to exit
```


## STEP:3 Creating the WSGI Entry Point (if not created):
- create a file (in the same directory where your `app.py` file resides) that will serve as the entry point for your application. This will tell the Gunicorn server how to interact with the application. copy the below code to `wsgi.py`
```python
from app import app

if __name__ == "__main__":
    app.run()
```


## STEP:4 Setting GUNICORN:
```bash
# first complete all the above steps, then perform the below steps:
# activate the virtual environment if not activated yet
$ source appvenv/bin/activate
$ cd live-repo/uihelpdesk
$ gunicorn --bind 0.0.0.0:5000 wsgi:app
# hit CTRL-C to exit
$ deactivate
```


## STEP:5 Creating Service to Gunicorn:
- NOTE: virtual environment should be deactivated
```bash
$ sudo nano /etc/systemd/system/uihelpdesk.service
# copy the below code for the service
[Unit]
Description=Gunicorn instance to serve UIHelpdesk
After=network.target

[Service]
User=abbas
Group=www-data
WorkingDirectory=/home/abbas/live-repo/uihelpdesk/
Environment="PATH=/home/abbas/live-repo/uihelpdesk/appvenv/bin"
EnvironmentFile=/home/abbas/live-repo/uihelpdesk/.env
ExecStart=/home/abbas/live-repo/uihelpdesk/appvenv/bin/gunicorn --workers 3 --timeout 1000 --bind unix:app.sock -m 007 wsgi:app

[Install]
WantedBy=multi-user.target

# hit CTRL-X to exit
# hit Y and enter
# now run the below commands:
$ sudo systemctl start uihelpdesk
$ sudo systemctl status uihelpdesk # output must show Active: active (running)
# hit CTRL-C to exit
$ sudo systemctl enable uihelpdesk
# this will created symlink and following output will be returned
# /etc/systemd/system/multi-user.target.wants/uihelpdesk.service → /etc/systemd/system/uihelpdesk.service.
```


## STEP:6 Setting for NGINX
- virtual environment should be deactivated
```bash
$ sudo nano /etc/nginx/sites-available/uihelpdesk
# copy the below code for the above config file
server {
    listen 50002;
    server_name ngx.dev.iipak.local;

    location / {
        include proxy_params;
        proxy_pass http://unix:/home/abbas/live-repo/uihelpdesk/app.sock;
    }
}

# for https enabled server:
server {
    server_name _;

    ## for HTTP - uncomment the below code:
    #listen 5002 default;
    #listen [::]:5002 default;

    ## for HTTPS - uncomment the below code:
    listen 5002 ssl;
    listen [::]:5002 ssl;

    #ssl_certificate /etc/nginx/ssl/nginx.crt;
    #ssl_certificate_key /etc/nginx/ssl/nginx.key;
    ssl_certificate /etc/nginx/ssl/apps.akcpk.org.crt;
    ssl_certificate_key /etc/nginx/ssl/apps.akcpk.org.key;

    error_page 497 https://$host:$server_port$request_uri;
    
    location / {
        proxy_pass http://unix:/home/abbas/live-repo/uihelpdesk/app.sock;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location /static/ {
        alias /home/abbas/live-repo/uihelpdesk/static/;
    }
}


# hit CTRL-X to exit
# hit Y and enter
# now run the below commands:
$ sudo ln -s /etc/nginx/sites-available/uihelpdesk /etc/nginx/sites-enabled
# to check if the symbolic link exists
$ ls -l /etc/nginx/sites-enabled 
$ sudo nginx -t
# below should be return
# nginx: the configuration file /etc/nginx/nginx.conf syntax is ok
# nginx: configuration file /etc/nginx/nginx.conf test is successful
$ sudo systemctl restart nginx
$ sudo ufw delete allow 5000
# this should be return
# Rule deleted
# Rule deleted (v6)
$ sudo ufw allow 'Nginx Full'
# below will be return if rule is already exists
# Skipping adding existing rule
# Skipping adding existing rule (v6)
$ sudo ufw allow 50002 # this is the same port which is used in your config file
```


## Setting for permission to access the project folder:
- Note: You will receive an HTTP 502 gateway error if Nginx cannot access gunicorn’s socket file. Usually this is because the user’s home directory does not allow other users to access files inside it.

- If your sock file is called /home/abbas/live-repo/uihelpdesk/app.sock, ensure that /home/abbas has a minimum of 0755 permissions. You can use a tool like chmod to change the permissions like below:
```bash
$ sudo chmod 755 /home/abbas
# if you encounter any errors, trying checking the following:
$ sudo less /var/log/nginx/error.log  # to checks the Nginx error logs.
$ sudo less /var/log/nginx/access.log # to checks the Nginx access logs.
$ sudo journalctl -u nginx # to checks the Nginx process logs.
$ sudo journalctl -u uihelpdesk # to checks your Flask app’s Gunicorn logs.
```



# Zoom Meeting Scheduling Application (HelpDesk)

## Overview
The **Zoom Meeting Scheduling Application** is a Flask-based web application that allows users to request Zoom meeting slots according to their needs. The application provides an easy-to-use interface for scheduling meetings, managing user sessions, and storing meeting details in a SQLite database.

## Features
- **User Registration & Session Management**: Users can log in, manage their sessions, and are automatically logged out after inactivity.
- **Zoom Meeting Scheduling**: Users can request Zoom meetings by selecting the date, time, title, and description.
- **Meeting Modification & Tracking**: The system keeps track of meeting creation and modification history.
- **SQLite Database Integration**: All meeting details and user data are stored using SQLAlchemy with SQLite.
- **Secure Authentication**: Session-based authentication with automatic session expiration.
- **Web-based Interface**: Simple and responsive UI for scheduling and managing meetings.

## Technologies Used
- **Python 3**
- **Flask** (Backend framework)
- **Flask-SQLAlchemy** (ORM for database management)
- **SQLite** (Database)
- **HTML, CSS, JavaScript** (Frontend)

## Installation Guide
### Prerequisites
Make sure you have Python installed on your system.
```bash
python --version
```
If not installed, download and install it from [Python's official website](https://www.python.org/downloads/).

### Setup Instructions
1. **Clone the repository**:
   ```bash
   git clone https://github.com/yourusername/zoom-meeting-scheduler.git
   cd zoom-meeting-scheduler
   ```
2. **Create a virtual environment**:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```
3. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```
4. **Run the application**:
   ```bash
   python app.py
   ```
5. **Access the application in the browser**:
   ```
   http://127.0.0.1:5000/
   ```

## Database Schema
### User Table
| Field        | Type     | Description |
|-------------|---------|-------------|
| id          | Integer | Primary Key |
| name        | String  | User's name |
| region      | String  | User's region |
| raised_by   | String  | Person who created the request |
| status      | String  | User's session status |
| status_time | DateTime | Timestamp of current status |
| json_data   | JSON    | Additional user info |

### Zoom Meeting Table
| Field        | Type     | Description |
|-------------|---------|-------------|
| id          | Integer | Primary Key |
| user_id     | Integer | Foreign key to User table |
| created_by  | String  | Name of the creator |
| region      | String  | Meeting region |
| created_on  | DateTime | Meeting creation timestamp |
| modified_by | String  | Last person who modified the request |
| modified_on | DateTime | Last modification timestamp |
| meeting_title | String | Title of the meeting |
| description | String | Meeting description |
| date        | Date    | Meeting date |
| time        | Time    | Meeting time |
| am_pm       | String  | AM/PM notation |
| time_hours  | Integer | Meeting hour |
| time_minutes | Integer | Meeting minutes |
| remarks     | String  | Additional remarks |
| json_data   | JSON    | Extra meeting details |

## API Endpoints (if applicable)
| Method | Endpoint         | Description |
|--------|-----------------|-------------|
| GET    | `/`             | Home Page |
| POST   | `/schedule`     | Schedule a Zoom meeting |
| GET    | `/meetings`     | List all scheduled meetings |
| GET    | `/meeting/<id>` | View details of a specific meeting |
| POST   | `/update/<id>`  | Update a scheduled meeting |
| DELETE | `/delete/<id>`  | Delete a meeting |

## Contribution Guide
If you'd like to contribute:
1. Fork the repository.
2. Create a new branch (`git checkout -b feature-branch`).
3. Commit your changes (`git commit -m 'Add new feature'`).
4. Push to the branch (`git push origin feature-branch`).
5. Create a Pull Request.

## License
This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Contact
For any inquiries or support, please contact:
- **Email**: your_email@example.com
- **GitHub**: [Your GitHub Profile](https://github.com/yourusername)
- **LinkedIn**: [Your LinkedIn Profile](https://linkedin.com/in/yourprofile)

---
🚀 **Enjoy Scheduling Your Zoom Meetings Efficiently!**
